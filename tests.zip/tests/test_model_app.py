from pyexpat import model
import streamlit as st
import pandas as pd
from pycaret.regression import load_model
from pycaret.regression import predict_model
import numpy as np
import requests

data_path = '../data/archive/world_wide_self_harm_and_substance_deaths.csv'
dataset1 = pd.read_csv(data_path)
dataset = dataset1.drop(['Age_and_Sex_Population', 'ISO_Code','Deaths'], axis=1)


def estructura():

    columns = ["Year", "Cause", "Age_Range", "Sex", "Country"]
    empty_df = pd.DataFrame(columns=columns)
    session_state = st.session_state
    if "df" not in session_state:
        session_state.df = empty_df
        session_state.row = pd.Series(index=columns)
    for col in columns:
        if col == "Year":
            values = list(dataset['Year'].unique())
        elif col == "Cause":
            values = list(dataset['Cause'].unique())
        elif col == "Age_Range":
            values = list(dataset['Age_Range'].unique())
        elif col == "Sex":
            values = list(dataset['Sex'].unique())
        elif col == "Country":
            values = list(dataset['Country'].unique())
        
        
        index = values.index(session_state.row[col]) if session_state.row[col] in values else 0

        session_state.row[col] = st.selectbox(col, values, key=col, index=index)

  
    if st.button("Agregar Fila"):
        session_state.df = session_state.df.append(session_state.row, ignore_index=True)
        session_state.row = pd.Series(index=columns)


    st.dataframe(session_state.df)
    restructurado = pd.get_dummies(session_state.df, columns=session_state.df.columns)
   #creando base para conocer todas las columnas a tener
    base=pd.get_dummies(dataset,columns=dataset.columns)

    # Lista de columnas faltantes
    missing_cols = [col for col in base.columns if col not in restructurado.columns]

    # Agregar columnas faltantes con valores predeterminados (en este caso, 0)
    for col in missing_cols:
        restructurado[col] = 0 
#boton para predecir
    get_pred = st.button("Predecir")
    
    if(get_pred):
        data_to_predict = pd.DataFrame({'Year_2017': restructurado['Year_2017'],
                                        'Year_2018': 	restructurado['Year_2018' ],
                                        'Year_2019': 	restructurado['Year_2019' ],
                                        'Year_2020': 	restructurado['Year_2020' ],
                                        'Year_2021': 	restructurado['Year_2021' ],
                                        'Cause_Intentional self-harm': 	restructurado['Cause_Intentional self-harm' ],
                                        'Cause_Mental and behavioural disorders due to psychoactive substance use': 	restructurado['Cause_Mental and behavioural disorders due to psychoactive substance use' ],
                                        'Age_Range_0': 	restructurado['Age_Range_0' ],
                                        'Age_Range_1': 	restructurado['Age_Range_1' ],
                                        'Age_Range_10-14': 	restructurado['Age_Range_10-14' ],
                                        'Age_Range_15-19': 	restructurado['Age_Range_15-19' ],
                                        'Age_Range_15-24': 	restructurado['Age_Range_15-24' ],
                                        'Age_Range_20-24': 	restructurado['Age_Range_20-24' ],
                                        'Age_Range_25-29': 	restructurado['Age_Range_25-29' ],
                                        'Age_Range_25-34': 	restructurado['Age_Range_25-34' ],
                                        'Age_Range_3': 	restructurado['Age_Range_3' ],
                                        'Age_Range_30-34': 	restructurado['Age_Range_30-34' ],
                                        'Age_Range_35-39': 	restructurado['Age_Range_35-39' ],
                                        'Age_Range_35-44': 	restructurado['Age_Range_35-44' ],
                                        'Age_Range_4': 	restructurado['Age_Range_4' ],
                                        'Age_Range_40-44': 	restructurado['Age_Range_40-44' ],
                                        'Age_Range_45-49': 	restructurado['Age_Range_45-49' ],
                                        'Age_Range_45-54': 	restructurado['Age_Range_45-54' ],
                                        'Age_Range_5-14': 	restructurado['Age_Range_5-14' ],
                                        'Age_Range_5-9': 	restructurado['Age_Range_5-9' ],
                                        'Age_Range_50-54': 	restructurado['Age_Range_50-54' ],
                                        'Age_Range_55-59': 	restructurado['Age_Range_55-59' ],
                                        'Age_Range_55-64': 	restructurado['Age_Range_55-64' ],
                                        'Age_Range_60-64': 	restructurado['Age_Range_60-64' ],
                                        'Age_Range_65-69': 	restructurado['Age_Range_65-69' ],
                                        'Age_Range_65-74': 	restructurado['Age_Range_65-74' ],
                                        'Age_Range_70-74': 	restructurado['Age_Range_70-74' ],
                                        'Age_Range_75+': 	restructurado['Age_Range_75+' ],
                                        'Age_Range_75-79': 	restructurado['Age_Range_75-79' ],
                                        'Age_Range_80-84': 	restructurado['Age_Range_80-84' ],
                                        'Age_Range_85+': 	restructurado['Age_Range_85+' ],
                                        'Age_Range_85-89': 	restructurado['Age_Range_85-89' ],
                                        'Age_Range_90-94': 	restructurado['Age_Range_90-94' ],
                                        'Age_Range_95+': 	restructurado['Age_Range_95+' ],
                                        'Age_Range_All': 	restructurado['Age_Range_All' ],
                                        'Age_Range_Unknown': 	restructurado['Age_Range_Unknown' ],
                                        'Sex_All': 	restructurado['Sex_All' ],
                                        'Sex_Female': 	restructurado['Sex_Female' ],
                                        'Sex_Male': 	restructurado['Sex_Male' ],
                                        'Sex_Unspecified': 	restructurado['Sex_Unspecified' ],
                                        'Country_Andorra': 	restructurado['Country_Andorra' ],
                                        'Country_Anguilla': 	restructurado['Country_Anguilla' ],
                                        'Country_Antigua and Barbuda': 	restructurado['Country_Antigua and Barbuda' ],
                                        'Country_Argentina': 	restructurado['Country_Argentina' ],
                                        'Country_Armenia': 	restructurado['Country_Armenia' ],
                                        'Country_Aruba': 	restructurado['Country_Aruba' ],
                                        'Country_Australia': 	restructurado['Country_Australia' ],
                                        'Country_Austria': 	restructurado['Country_Austria' ],
                                        'Country_Belarus': 	restructurado['Country_Belarus' ],
                                        'Country_Belgium': 	restructurado['Country_Belgium' ],
                                        'Country_Bermuda': 	restructurado['Country_Bermuda' ],
                                        'Country_Bosnia and Herzegovina': 	restructurado['Country_Bosnia and Herzegovina' ],
                                        'Country_Brazil': 	restructurado['Country_Brazil' ],
                                        'Country_Brunei Darussalam': 	restructurado['Country_Brunei Darussalam' ],
                                        'Country_Bulgaria': 	restructurado['Country_Bulgaria' ],
                                        'Country_Canada': 	restructurado['Country_Canada' ],
                                        'Country_Chile': 	restructurado['Country_Chile' ],
                                        'Country_Colombia': 	restructurado['Country_Colombia' ],
                                        'Country_Costa Rica': 	restructurado['Country_Costa Rica' ],
                                        'Country_Croatia': 	restructurado['Country_Croatia' ],
                                        'Country_Cuba': 	restructurado['Country_Cuba' ],
                                        'Country_Cyprus': 	restructurado['Country_Cyprus' ],
                                        'Country_Czech Republic': 	restructurado['Country_Czech Republic' ],
                                        'Country_Denmark': 	restructurado['Country_Denmark' ],
                                        'Country_Dominica': 	restructurado['Country_Dominica' ],
                                        'Country_Dominican Republic': 	restructurado['Country_Dominican Republic' ],
                                        'Country_Ecuador': 	restructurado['Country_Ecuador' ],
                                        'Country_Egypt': 	restructurado['Country_Egypt' ],
                                        'Country_El Salvador': 	restructurado['Country_El Salvador' ],
                                        'Country_Estonia': 	restructurado['Country_Estonia' ],
                                        'Country_Finland': 	restructurado['Country_Finland' ],
                                        'Country_France': 	restructurado['Country_France' ],
                                        'Country_French Guiana': 	restructurado['Country_French Guiana' ],
                                        'Country_Georgia': 	restructurado['Country_Georgia' ],
                                        'Country_Germany': 	restructurado['Country_Germany' ],
                                        'Country_Greece': 	restructurado['Country_Greece' ],
                                        'Country_Grenada': 	restructurado['Country_Grenada' ],
                                        'Country_Guadeloupe': 	restructurado['Country_Guadeloupe' ],
                                        'Country_Guatemala': 	restructurado['Country_Guatemala' ],
                                        'Country_Guyana': 	restructurado['Country_Guyana' ],
                                        'Country_Hong Kong SAR': 	restructurado['Country_Hong Kong SAR' ],
                                        'Country_Hungary': 	restructurado['Country_Hungary' ],
                                        'Country_Iceland': 	restructurado['Country_Iceland' ],
                                        'Country_Ireland': 	restructurado['Country_Ireland' ],
                                        'Country_Israel': 	restructurado['Country_Israel' ],
                                        'Country_Italy': 	restructurado['Country_Italy' ],
                                        'Country_Japan': 	restructurado['Country_Japan' ],
                                        'Country_Jordan': 	restructurado['Country_Jordan' ],
                                        'Country_Kazakhstan': 	restructurado['Country_Kazakhstan' ],
                                        'Country_Kuwait': 	restructurado['Country_Kuwait' ],
                                        'Country_Kyrgyzstan': 	restructurado['Country_Kyrgyzstan' ],
                                        'Country_Latvia': 	restructurado['Country_Latvia' ],
                                        'Country_Lebanon': 	restructurado['Country_Lebanon' ],
                                        'Country_Libyan Arab Jamahiriya': 	restructurado['Country_Libyan Arab Jamahiriya' ],
                                        'Country_Lithuania': 	restructurado['Country_Lithuania' ],
                                        'Country_Luxembourg': 	restructurado['Country_Luxembourg' ],
                                        'Country_Malaysia': 	restructurado['Country_Malaysia' ],
                                        'Country_Maldives': 	restructurado['Country_Maldives' ],
                                        'Country_Malta': 	restructurado['Country_Malta' ],
                                        'Country_Martinique': 	restructurado['Country_Martinique' ],
                                        'Country_Mauritius': 	restructurado['Country_Mauritius' ],
                                        'Country_Mayotte': 	restructurado['Country_Mayotte' ],
                                        'Country_Mexico': 	restructurado['Country_Mexico' ],
                                        'Country_Mongolia': 	restructurado['Country_Mongolia' ],
                                        'Country_Montenegro': 	restructurado['Country_Montenegro' ],
                                        'Country_Netherlands': 	restructurado['Country_Netherlands' ],
                                        'Country_Nicaragua': 	restructurado['Country_Nicaragua' ],
                                        'Country_North Macedonia': 	restructurado['Country_North Macedonia' ],
                                        'Country_Occupied Palestinian Territory': 	restructurado['Country_Occupied Palestinian Territory' ],
                                        'Country_Oman': 	restructurado['Country_Oman' ],
                                        'Country_Panama': 	restructurado['Country_Panama' ],
                                        'Country_Paraguay': 	restructurado['Country_Paraguay' ],
                                        'Country_Peru': 	restructurado['Country_Peru' ],
                                        'Country_Philippines': 	restructurado['Country_Philippines' ],
                                        'Country_Poland': 	restructurado['Country_Poland' ],
                                        'Country_Portugal': 	restructurado['Country_Portugal' ],
                                        'Country_Puerto Rico': 	restructurado['Country_Puerto Rico' ],
                                        'Country_Qatar': 	restructurado['Country_Qatar' ],
                                        'Country_Republic of Korea': 	restructurado['Country_Republic of Korea' ],
                                        'Country_Republic of Moldova': 	restructurado['Country_Republic of Moldova' ],
                                        'Country_Reunion': 	restructurado['Country_Reunion' ],
                                        'Country_Rodrigues': 	restructurado['Country_Rodrigues' ],
                                        'Country_Romania': 	restructurado['Country_Romania' ],
                                        'Country_Russian Federation': 	restructurado['Country_Russian Federation' ],
                                        'Country_Saint Lucia': 	restructurado['Country_Saint Lucia' ],
                                        'Country_Saint Vincent and Grenadines': 	restructurado['Country_Saint Vincent and Grenadines' ],
                                        'Country_San Marino': 	restructurado['Country_San Marino' ],
                                        'Country_Serbia': 	restructurado['Country_Serbia' ],
                                        'Country_Seychelles': 	restructurado['Country_Seychelles' ],
                                        'Country_Singapore': 	restructurado['Country_Singapore' ],
                                        'Country_Slovakia': 	restructurado['Country_Slovakia' ],
                                        'Country_Slovenia': 	restructurado['Country_Slovenia' ],
                                        'Country_Solomon Islands': 	restructurado['Country_Solomon Islands' ],
                                        'Country_South Africa': 	restructurado['Country_South Africa' ],
                                        'Country_Spain': 	restructurado['Country_Spain' ],
                                        'Country_Sweden': 	restructurado['Country_Sweden' ],
                                        'Country_Switzerland': 	restructurado['Country_Switzerland' ],
                                        'Country_Tajikistan': 	restructurado['Country_Tajikistan' ],
                                        'Country_Thailand': 	restructurado['Country_Thailand' ],
                                        'Country_Tunisia': 	restructurado['Country_Tunisia' ],
                                        'Country_Turkey': 	restructurado['Country_Turkey' ],
                                        'Country_Turks and Caicos Islands': 	restructurado['Country_Turks and Caicos Islands' ],
                                        'Country_Ukraine': 	restructurado['Country_Ukraine' ],
                                        'Country_United Arab Emirates': 	restructurado['Country_United Arab Emirates' ],
                                        'Country_United Kingdom': 	restructurado['Country_United Kingdom' ],
                                        'Country_United States of America': 	restructurado['Country_United States of America' ],
                                        'Country_Uruguay': 	restructurado['Country_Uruguay' ],
                                        'Country_Uzbekistan': 	restructurado['Country_Uzbekistan' ],
                                        'Country_Virgin Islands (USA)':	restructurado['Country_Virgin Islands (USA)']})
      

       

        result = data_to_predict.to_dict(orient="records")
        
        r = requests.post(url="http://127.0.0.1:5000/predictOne", json = result)
        print(r)
        st.write(list(r))

def main():
    st.set_page_config(page_title="Inicio")
    st.write("# Proyecto 2: Naomi Lara / Héctor Aragón / Jorge Yxcot")
# valor default del modelo
    requests.get('http://127.0.0.1:5000/get_dato', params={'dato': '../models/modelo2'})
    modeloSelect = st.selectbox("Modelo a utilizar", options=["Modelo1","Modelo2","Modelo3"])
    if modeloSelect=="Modelo1":
        requests.get('http://127.0.0.1:5000/get_dato', params={'dato': '../../models/modelo1'})
    if modeloSelect=="Modelo2":
        requests.get('http://127.0.0.1:5000/get_dato', params={'dato': '../../models/modelo2'})
    if modeloSelect=="Modelo3":
        requests.get('http://127.0.0.1:5000/get_dato', params={'dato': '../../models/modelo3'})
    estructura()

   

        

if(__name__=='__main__'):
    main()