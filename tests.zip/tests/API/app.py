from flask import Flask,request,jsonify, session
import pandas as pd
from pycaret.regression import load_model
from pycaret.regression import predict_model
from datetime import datetime

app = Flask(__name__)

#modelo default si no se selecciona alguno
dato_obtenido = '../models/modelo2'


@app.route('/saludo', methods=['GET']) #GET es cuando queremos leer información
def saludo():
        strOut="Hola mundo"
        print(strOut)
        return jsonify({'mensaje':strOut}) #prueba para ver si conecta API


@app.route('/get_dato', methods=['GET']) #GET es cuando queremos leer información
def obtener_dato():
    global dato_obtenido
    dato_obtenido = request.args.get('dato')
    return f'Dato recibido: {dato_obtenido}'


@app.route('/predictOne',methods=['POST']) #aqui recibe un unico JSON hay que investigar como hacer para que sea JSON de JSON que eso es BATCH
def predictOne():
        global dato_obtenido
        if dato_obtenido is not None:
                data=request.json
                data=pd.json_normalize(data) #convertimos a dataframe con los tipos de datos default
                model=load_model(dato_obtenido)
                print(data)
                
                try:
                        prediccion = predict_model(model, data=data)
                        
                        with open('model_logs.log', 'a') as archivo_modificado:
                                for valor_predicho in prediccion['prediction_label']:
                                        valor_predicho = round(valor_predicho, 4)
                                        current_date = datetime.now()
                                        substring =dato_obtenido[13:21]
                                        strLog = f'Modelo:{substring} - Predicted_Value:{valor_predicho} - Date:{current_date.strftime("%Y-%m-%d %H:%M:%S")}\n'
                                        archivo_modificado.write(strLog)

                        
                        return jsonify({'prediccion':list(prediccion['prediction_label'])})
                except:
                        with open('model_logs.log','a') as archivo_modificado:
                                #escribe el contenido modificado en el archivo
                                current_date = datetime.now()
                                strLog=f'Error,{current_date.strftime("%Y-%m-%d %H:%M:%S")}\n'
                                archivo_modificado.write(strLog)
                        return jsonify({'mensaje':'Se generó un error en la predicción'})
        else:
                return jsonify({'mensaje':'No hay tipo modelo'})